b6.b
